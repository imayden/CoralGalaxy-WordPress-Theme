# CoralGalaxy-WordPress-Theme
This is a comprehensive WordPress theme developed with PHP, JS and WordPress by Ayden Deng based on the underscores blank theme template.
